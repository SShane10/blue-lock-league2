# Blue Lock League V7 Pro — Local Edition

V7, V6 Local verilerini otomatik olarak yeni formata taşır.

## Öne çıkanlar
- Maç yaşam döngüsü: Yakında → Canlı → Bitti
- **Maçı Başlat** ve **Maçı Bitir** butonları
- Gol eklenince skor otomatik +1
- Yeni eklenen gol silinirse skor otomatik geri alınır
- Canlı maç kontrol konsolu
- Gole doğrudan asist bağlama
- Match Up ve kritik müdahale kayıtları
- Sezon filtreleri, puan tablosu ve otomatik ödüller
- Oyuncu fotoğrafı / takım logosu URL veya bilgisayardan yükleme
- Oyuncu, takım, maç ve sezon düzenleme
- JSON yedek alma / geri yükleme
- V6 localStorage verilerini otomatik taşıma

## Kurulum
GitHub Pages reposunun kökündeki eski `index.html` dosyasını bu paketteki `index.html` ile değiştir.

## Veri notu
Bu sürüm Supabase kullanmaz. Veriler her tarayıcının kendi localStorage alanında tutulur. Başka cihazdaki ziyaretçiler aynı veriyi otomatik görmez.

## Admin notu
Admin şifresi kaynak kodda düz metin olarak tutulmaz; SHA-256 özetiyle kontrol edilir. Statik GitHub Pages üzerinde bu, sunucu tarafı güvenlik anlamına gelmez.

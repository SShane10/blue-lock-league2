# Blue Lock League v6 Local

Bu sürüm Supabase / SQL kullanmaz. Tek dosyalık GitHub Pages sürümüdür.

## Özellikler
- Sezon sistemi ve aktif sezon seçimi
- Oyuncu / takım / maç ekleme, düzenleme ve silme
- Oyuncu fotoğrafı: URL veya bilgisayardan dosya
- Takım logosu: URL veya bilgisayardan dosya
- Gol, gole bağlı asist, tek başına asist, Match Up, kritik müdahale
- Piyasa değeri: Gol 700K, Asist 600K, Match Up 100K, Kritik 500K
- Son 5 katkı göstergesi
- MVP, Golden Boot, Playmaker, Defender kartları
- JSON yedek alma ve geri yükleme
- v4 localStorage verisini ilk açılışta otomatik dönüştürme
- Admin şifresi düz metin yerine SHA-256 özetiyle kontrol edilir

## Kurulum
GitHub repo kökündeki mevcut `index.html` dosyasını bu paketteki `index.html` ile değiştir.

## Önemli
Bu sürümde veriler `localStorage` içindedir. Yani aynı cihaz + aynı tarayıcı profilinde kalır; farklı ziyaretçiler aynı veriyi paylaşmaz. Admin panelinden JSON yedeği alabilirsin.

GitHub Pages statik hosting olduğu için admin kontrolü gerçek sunucu tarafı güvenlik değildir. Normal kullanıcı şifreyi kaynakta düz metin göremez, ancak ileri düzey bir kullanıcı istemci tarafı kontrollerini aşabilir.

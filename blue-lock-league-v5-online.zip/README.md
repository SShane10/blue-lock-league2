# Blue Lock League v5 — Online Supabase Sürümü

Bu sürümde veriler artık `localStorage` yerine Supabase PostgreSQL'de tutulur.
Böylece herkes aynı oyuncuları, maçları ve sıralamaları görür.

## 1. Supabase projesi oluştur

Supabase Dashboard'da yeni bir proje oluştur.

## 2. Veritabanını kur

Supabase:
`SQL Editor` → `New query`

Bu paketteki:

`schema.sql`

dosyasının tamamını yapıştır ve `Run` de.

## 3. Admin hesabı oluştur

Supabase:
`Authentication` → `Users` → `Add user`

Kendi e-posta ve şifrenle bir kullanıcı oluştur.

Kullanıcının `User UID` değerini kopyala.

Sonra SQL Editor'da:

```sql
update public.profiles
set role = 'admin'
where id = 'BURAYA_AUTH_USER_UUID';
```

çalıştır.

Kontrol:

```sql
select * from public.profiles;
```

`role` sütununda `admin` görmelisin.

## 4. Project URL + Anon Key

Supabase Project Settings / API bölümünden:

- Project URL
- Publishable key / anon key

değerlerini al.

`index.html` dosyasını aç ve şu bölümü bul:

```js
const SUPABASE_URL = "YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
```

Kendi bilgilerinle değiştir.

ÖRNEK:

```js
const SUPABASE_URL = "https://abcxyz.supabase.co";
const SUPABASE_ANON_KEY = "eyJ...";
```

**Service Role Key kullanma.** Service Role Key hiçbir zaman GitHub Pages frontend'ine konmaz.

## 5. GitHub

Repository kökündeki eski `index.html` dosyasını v5'teki `index.html` ile değiştir.

Repository şöyle görünmesi yeterli:

```text
blue-lock-league2/
└── index.html
```

`schema.sql` dosyasını repo'ya koymak zorunda değilsin.

GitHub Pages:
- Settings
- Pages
- Deploy from a branch
- Branch: `main`
- Folder: `/ (root)`

## 6. Admin girişi

Site → `Admin Paneli`

Supabase Authentication'da oluşturduğun e-posta ve şifreyle giriş yap.

Admin panelinden:

- takım ekle
- oyuncu ekle
- maç ekle
- gol ekle
- asist ekle
- Match Up ekle
- kritik müdahale ekle
- maç olayını sil

## 7. Değer sistemi

- Gol = 700.000 ₺
- Asist = 600.000 ₺
- Match Up = 100.000 ₺
- Kritik müdahale = 500.000 ₺

Oyuncunun değeri `match_events` tablosundan otomatik hesaplanır.

## Güvenlik

Public kullanıcılar sadece lig verisini okuyabilir.

Takım / oyuncu / maç / olay ekleme-silme işlemleri Supabase RLS sayesinde yalnızca `profiles.role = 'admin'` olan giriş yapmış kullanıcılara açıktır.

Anon key'in frontend'de görünmesi normaldir. Güvenliği anon key değil RLS sağlar.

**Service Role Key'i siteye koyma.**

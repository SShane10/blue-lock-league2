-- BLUE LOCK LEAGUE v5
-- Supabase > SQL Editor > New Query > tamamını yapıştır > Run

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  role text not null default 'viewer' check (role in ('admin','editor','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  logo_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  team_id uuid references public.teams(id) on delete set null,
  position text,
  number integer,
  age integer,
  bio text,
  image_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  home_team_id uuid not null references public.teams(id) on delete restrict,
  away_team_id uuid not null references public.teams(id) on delete restrict,
  home_score integer not null default 0 check (home_score >= 0),
  away_score integer not null default 0 check (away_score >= 0),
  status text not null default 'upcoming' check (status in ('upcoming','live','finished')),
  played_at timestamptz,
  created_at timestamptz not null default now(),
  check (home_team_id <> away_team_id)
);

create table if not exists public.match_events (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  player_id uuid not null references public.players(id) on delete cascade,
  event_type text not null check (event_type in ('goal','assist','match_up','critical_intervention')),
  minute integer check (minute is null or (minute >= 0 and minute <= 150)),
  description text,
  created_at timestamptz not null default now()
);

-- Yeni Auth kullanıcısına otomatik profil aç.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'username', split_part(new.email,'@',1)), 'viewer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Admin kontrol fonksiyonu.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.teams enable row level security;
alter table public.players enable row level security;
alter table public.matches enable row level security;
alter table public.match_events enable row level security;

-- Eski policy'leri temizle (script tekrar çalıştırılabilsin).
drop policy if exists "profiles own read" on public.profiles;
drop policy if exists "admin profiles read" on public.profiles;
drop policy if exists "public teams read" on public.teams;
drop policy if exists "admin teams manage" on public.teams;
drop policy if exists "public players read" on public.players;
drop policy if exists "admin players manage" on public.players;
drop policy if exists "public matches read" on public.matches;
drop policy if exists "admin matches manage" on public.matches;
drop policy if exists "public events read" on public.match_events;
drop policy if exists "admin events manage" on public.match_events;

create policy "profiles own read"
on public.profiles for select
to authenticated
using (auth.uid() = id);

create policy "admin profiles read"
on public.profiles for select
to authenticated
using (public.is_admin());

create policy "public teams read"
on public.teams for select
to anon, authenticated
using (true);

create policy "admin teams manage"
on public.teams for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "public players read"
on public.players for select
to anon, authenticated
using (true);

create policy "admin players manage"
on public.players for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "public matches read"
on public.matches for select
to anon, authenticated
using (true);

create policy "admin matches manage"
on public.matches for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "public events read"
on public.match_events for select
to anon, authenticated
using (true);

create policy "admin events manage"
on public.match_events for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

-- İlk takım örnekleri (istersen admin panelinden silmeden üzerine devam et).
insert into public.teams (name) values
('PXG'),('Bastard München'),('Ubers'),('Manshine City')
on conflict (name) do nothing;

-- ADMIN YAPMA:
-- 1) Supabase Authentication > Users bölümünden kullanıcı oluştur.
-- 2) Kullanıcının UUID'sini kopyala.
-- 3) Aşağıdaki satırı UUID ile çalıştır:
--
-- update public.profiles
-- set role = 'admin'
-- where id = 'BURAYA_AUTH_USER_UUID';
--
-- Kontrol:
-- select * from public.profiles;

# Blue Lock League v4

Bu sürüm, örnek Blue Lock panelinin koyu mavi dashboard estetiğini baz alan bağımsız bir yeniden tasarımdır.

## En önemli nokta
CSS ve JavaScript doğrudan `index.html` içinde.
GitHub Pages'te ayrı CSS yolu kırıldığı için yaşanan "dümdüz yazı" sorunu bu sürümde oluşmaz.

## Kurulum
GitHub repository kökündeki eski `index.html` dosyasını bununla değiştir.

En temiz hali:
- index.html

GitHub Pages ayarı:
- Source: Deploy from a branch
- Branch: main
- Folder: / (root)

## Demo Admin
Şifre: admin123

Admin ile:
- takım ekle
- oyuncu ekle
- maç ekle
- gol ekle
- asist ekle
- Match Up ekle
- kritik müdahale ekle
- olay sil

## Değer sistemi
- Gol: 700.000 ₺
- Asist: 600.000 ₺
- Match Up: 100.000 ₺
- Kritik Müdahale: 500.000 ₺

## Önemli
Bu v4 verileri localStorage'da tutar. Yani her ziyaretçinin verisi kendi tarayıcısındadır.
Gerçek ortak lig veritabanı ve güvenli admin için sonraki aşamada Supabase bağlanmalıdır.

# Blue Lock League V7.1 Pro — Persistence Fix

Bu sürüm V7'nin veri kaybolma sorununa karşı kalıcı kayıt katmanını güçlendirir.

## Düzeltmeler
- Her değişiklik localStorage'a kaydedilir.
- Aynı veri ayrıca IndexedDB'ye yedeklenir.
- Sayfa yenilendiğinde localStorage eksik/eski ise IndexedDB yedeği otomatik geri yüklenir.
- Sayfa kapanırken son bir kayıt daha yapılır.
- Tarayıcı destekliyorsa kalıcı depolama talep edilir.
- Yüklenen görseller daha küçük WebP/JPEG olarak sıkıştırılır; depolama kotasını daha az tüketir.
- V7, V6 Local ve V4 verileri korunarak taşınmaya devam eder.

## Önemli
Bu hâlâ GitHub Pages üzerinde local bir sistemdir. Veriler aynı tarayıcı/cihazda kalır.
Başka cihazlarda ortak veri için gerçek bir backend gerekir.

## Kurulum
Repo kökündeki eski index.html dosyasını bu paketteki index.html ile değiştir.

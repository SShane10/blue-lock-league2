-- BLUE LOCK LEAGUE v6 UPGRADE
-- Mevcut v5 veritabanında Supabase > SQL Editor > New Query kısmında çalıştır.

create table if not exists public.seasons (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  start_date date,
  end_date date,
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.seasons enable row level security;

drop policy if exists "public seasons read" on public.seasons;
drop policy if exists "admin seasons manage" on public.seasons;

create policy "public seasons read"
on public.seasons for select
to anon, authenticated
using (true);

create policy "admin seasons manage"
on public.seasons for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Aynı anda yalnızca bir aktif sezon.
create unique index if not exists one_active_season
on public.seasons ((is_active))
where is_active = true;

alter table public.matches
add column if not exists season_id uuid references public.seasons(id) on delete set null;

alter table public.match_events
add column if not exists assist_player_id uuid references public.players(id) on delete set null;

-- İlk sezon yoksa oluştur.
insert into public.seasons (name, is_active)
select 'Sezon 1', true
where not exists (select 1 from public.seasons);

-- Aktif sezon yoksa en eski sezonu aktif yap.
update public.seasons
set is_active = true
where id = (
  select id from public.seasons
  order by created_at asc
  limit 1
)
and not exists (
  select 1 from public.seasons where is_active = true
);

-- Eski maçları aktif sezona bağla.
update public.matches
set season_id = (
  select id from public.seasons
  where is_active = true
  limit 1
)
where season_id is null;

NOTIFY pgrst, 'reload schema';

-- Kontrol:
-- select * from public.seasons;
-- select id, season_id, home_team_id, away_team_id from public.matches;

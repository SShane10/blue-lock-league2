# Blue Lock League v6

v5'in çalışan Supabase altyapısını genişleten sürüm.

## v6 yenilikleri

- Sezon sistemi
- Aktif sezon seçimi
- Sezona göre lig tablosu / sıralamalar / maçlar
- Oyuncu düzenleme ve silme
- Takım düzenleme ve silme
- Maç düzenleme ve silme
- Oyuncu fotoğraf URL'si
- Takım logo URL'si
- Gol olayına doğrudan asist oyuncusu bağlama
- Eski `assist` olaylarıyla geriye dönük uyumluluk
- Oyuncu profilinde son 5 maç katkı göstergesi
- Dashboard'da otomatik MVP / Golden Boot / Playmaker / Defender
- Admin kayıt yönetim ekranları

## Kurulum

### 1. Önce SQL yükseltmesini çalıştır

Supabase → SQL Editor → New Query

`upgrade-v6.sql` dosyasının tamamını çalıştır.

`Success` geldikten sonra Table Editor'da:
- `seasons`
- `matches.season_id`
- `match_events.assist_player_id`

alanlarını görmelisin.

### 2. GitHub index.html

Paketteki `index.html` senin mevcut Supabase bağlantı ayarlarını koruyacak şekilde hazırlanmıştır.

GitHub'daki mevcut `index.html` dosyasını bununla değiştir.

### 3. Yenile

GitHub Pages deploy bittikten sonra siteyi `Ctrl + F5` ile yenile.

## Önemli

Takım silme, o takım mevcut bir maçta kullanılmışsa veritabanı tarafından engellenebilir. Önce ilgili maçları silmek veya düzenlemek gerekir.

Piyasa değerleri:
- Gol: 700.000 ₺
- Asist: 600.000 ₺
- Match Up: 100.000 ₺
- Kritik Müdahale: 500.000 ₺
